Para instalar o usar la tipograf�a "La Pejina" debe estar de acuerdo con las condiciones de uso.
By installing or using this font (La Pejina) you agree to the Product Usage Agreement:
http://defharo.com/product-usage-agreement-ffp/
========================================
Esta fuente es s�lo para uso personal, el uso comercial requiere una licencia.
This font is for PERSONAL USE ONLY and requires a license for commercial use. 
http://defharo.com/terms-and-conditions-commercial-fonts/
========================================
La licencia comercial se obtiene con una donaci�n al autor en:
The font license can be found and donate at: 
http://defharo.com/dise�o-grafico/tipografia/la-pejina-font/
========================================
Por favor lea las condiciones de la licencia s�lo para uso personal:
Please read "Free for personal use License | Fonts by deFharo" for more info:
http://defharo.com/free-for-personal-use-license/
========================================
Si necesita m�s informaci�n contacte con el dise�ador:
For further information, please contact designer:
========================================
Fernando Haro
fernando@defharo.es
www.defharo.com




